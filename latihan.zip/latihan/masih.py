import speech_recognition as srec
from gtts import gTTS
import os
import webbrowser
import pyaudio

def perintah():
    mendengar = srec.Recognizer()
    with srec.Microphone() as source:
        print('Mendengarkan....')
        suara = mendengar.listen(source,phrase_time_limit=5)
        try: 
            print('Diterima...')
            dengar = mendengar.recognize_google(suara, language='id-ID')
            print(dengar)

            if "buka google" in dengar.lower():
                buka_google()
            elif "buka youtube" in dengar.lower():
                buka_youtube()
            elif "simpan" in dengar.lower():
                simpan_suara(suara)
            else:
                ngomong(dengar)
        except: 
            pass

def ngomong(teks):
    bahasa = 'id'
    namafile = 'Ngomong.mp3'
    def reading():
        suara = gTTS(text=teks, lang=bahasa, slow=False)
        suara.save(namafile)
        os.system(f'start {namafile}')
    reading()

def buka_google():
    url = "https://www.google.com"
    webbrowser.open(url)

def buka_youtube():
    url = "https://www.youtube.com"
    webbrowser.open(url)

def simpan_suara(suara):
    wf = open("Simpan.mp3", "wb")
    wf.write(suara.get_raw_data())
    wf.close()
    print("Suara telah disimpan sebagai Simpan.mp3")

def run_michelle():
    perintah()

run_michelle()